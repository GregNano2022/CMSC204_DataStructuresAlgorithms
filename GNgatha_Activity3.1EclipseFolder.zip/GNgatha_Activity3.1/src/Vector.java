import java.io.Serializable;
import java.util.AbstractCollection;
import java.util.AbstractList;
import java.util.Collection;
import java.util.List;
import java.util.RandomAccess;

public class Vector<E>extends AbstractList<E>implements List<E>, RandomAccess, Cloneable, Serializable
{
	
	/**
	The array buffer into which the components of the vector are stored. 
	The capacity of the vector is the length of this array buffer, 
	and is at least large enough to contain all the vector's elements.
	Any array elements following the last element in the Vector are null.*/
	protected Object[] elementData;
	
	/**The number of valid components 
	in this Vector object. Components elementData[0] through elementData[elementCount-1] are the actual items.*/
	protected int elementCount;
	
	/**The amount by which the capacity of the vector is automatically incremented 
	 * when its size becomes greater than its capacity. 
	 * If the capacity increment is less than or equal to zero, the capacity of the 
	 * vector is doubled each time it needs to grow.
	 */
	protected int capacityIncrement;


	public char[] firstElement;

	private static String str;

	private E data;
	
	/**Constructs an empty vector with the specified initial capacity and capacity increment.
	@parm initialCapacity - the initial capacity of the vector
	capacityIncrement - the amount by which the capacity is increased when the vector overflows
	Throws:
	IllegalArgumentException - if the specified initial capacity is negative*/
	public Vector(int initialCapacity,
		      int capacityIncrement)
	{
		
	}
	/**Constructs an empty vector with the specified initial capacity and with its capacity increment equal to zero.
	@param str - the initial capacity of the vector
	@throws Throws:IllegalArgumentException - if the specified initial capacity is negative*/
	
	public Vector(String str)
	{
		
	}
	/**Constructs an empty vector so that its internal data array has size 10 and its standard capacity increment is zero.*/
	public Vector()
	{
		
	}
	
	/**Returns an enumeration of the components of this vector. The returned Enumeration object will generate all items in this vector. The first item generated is the item at index 0, then the item at index 1, and so on.
	@returns Returns an enumeration of the components of this vector*/
	//public Enumeration<E> elements()
	//{
		
	//}
	
	
	public void add(String str) {
		// TODO Auto-generated method stub
		
	}

	
	public boolean contains(String str) 
	{
		boolean containsZeroes=false;
	int zeroes=0;
	int ones=0;
		for (int i =0; i<str.length(); i++)
		{
			
		if (str.contains("0"))
		{
			zeroes++;
		
			System.out.println("String index of 0's:"+"pos 0's: "+str.indexOf(0));
		
			System.out.println("no.of 0's:" +" "+ zeroes);
		}
		if(str.contains("1"))
		
		{
			ones++;
		
			System.out.println("String index of 1's:"+" "+"pos 1's: "+str.indexOf(1));
			
	
				System.out.println("no. of 1's:" + " " + ones);
	
		}
		
		return true;
		}
		return true;
	}
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public boolean addAll(Collection<? extends E> c) {
		// TODO Auto-generated method stub
		return false;
	}
	//@Override
	//public E get(int index) {
		// TODO Auto-generated method stub
	//	return null;
	//}
	public int length() {
		
		// TODO Auto-generated method stub
	return modCount ;
	}

	public  E get(int index) {
		
		int countOnes=0;
		int countZeroes =0;
		Vector.str=" ";
	        for (int i = 0; i < str.length(); i++) {
	       
	    	if (str.charAt(i)=='0');
	    	{
	    			countZeroes++;
	    		
	    	
	    				System.out.println("no.of zeroes:"+" "+ countZeroes);	
	        
	    	}
	    		
	    		if(str.charAt(i)=='1');
	    		{
	    			countOnes++;
	    		}
	    		System.out.println("no of ones:"+" "+ countOnes);
	    		//System.out.println("CountZeroes"+" " +countZeroes);

	        }
			return data;
	        }
	
	E elementData(int index) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	public void elementCount(int i) {
		// TODO Auto-generated method stub
	
	}
	//public char[] elementAt(int i) {
		// TODO Auto-generated method stub
	//	this.ones=i;
	//	retu
	public char[] firstElement() {
		// TODO Auto-generated method stub
		//this;
		return firstElement;
	}
	public char[] search(int i) {
		// TODO Auto-generated method stub
		this.firstElement();
		return firstElement ;
	}
	public void push(String string) {
		// TODO Auto-generated method stub
		
	}
	}

	
	
	
	

