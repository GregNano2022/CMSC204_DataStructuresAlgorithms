/**Driver class to test Bitwise operation via Java Class<E> Vector methods
 * @author George Ngatha
 * 
 *
 */

public class VectorUtility {

	
	//public static String str;
	@SuppressWarnings("unlikely-arg-type")
	public static void main(String[] args) 
	{
		
		Vector<String> str = new Vector<String>();
		str.add("10011100111011001");
	//str.add("hello Java");
	//System.out.println(str.firstElement());
	System.out.println("index of 0's:"+" "+str.indexOf("0"));
	System.out.println("index of 1's:" + " " + str.indexOf("1"));
	System.out.println("hascode:"+" " + str.hashCode());
	System.out.println("String contains 0's:" + " " +str.contains("0"));
	System.out.println("String contains 1's':" + " " +str.contains("0"));
System.out.println(str.get('1'));
	//System.out.println(str.elementCount);
	//System.out.println(str.search(0));
	
	}
}
		


