
public class EmptyStackException extends Exception {

}
