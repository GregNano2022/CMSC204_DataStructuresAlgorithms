import java.io.Serializable;
import java.util.AbstractList;
import java.util.Collection;
import java.util.List;
import java.util.RandomAccess;

public class Stack<E> extends AbstractList<E> implements List<E>, RandomAccess, Cloneable, Serializable{
Stack<E> defaultVector = new Stack<E>(); //Here E represents Element Type.
//Vector<E> initialCapacityVector = new Vector<E>(int size);


	/**
	Pushes an item onto the top of this stack. This has exactly the same effect as:
		 addElement(item)
@param item - the item to be pushed onto this stack.
@return the item argument. */
	public E push(E str)
	{
		return str;
		
	}
	/**Removes the object at the top of this stack and returns that object as the value of this function.
	 * @throws EmptyStackException 
@ return Returns:The object at the top of this stack (the last item of the Vector object).
@throws Throws:EmptyStackException - if this stack is empty.*/
	public E pop() throws EmptyStackException
	{
		
		if (isEmpty())
			throw new EmptyStackException();
		return null;
		
	}
	
	
	/**Looks at the object at the top of this stack without removing it from the stack.
	@return Returns the object at the top of this stack (the last item of the Vector object).
	@throws EmptyStackException - if this stack is empty.*/
	public E peek() throws EmptyStackException
	{
		if (isEmpty())
			throw new EmptyStackException();
		return null;
		
	}
	/** Tests if this stack is empty.
	@returns Returns:true if and only if this stack contains no items; false otherwise.*/
	public boolean empty()
	{
		return false;
		
	}
	/**
	Returns the 1-based position where an object is on this stack. If the object o occurs as an item in this stack, this method returns the distance from the top of the stack of the occurrence nearest the top of the stack; the topmost item on the stack is considered to be at distance 1. The equals method is used to compare o to the items in this stack.
	@param o - the desired object.
	@return Returns:the 1-based position from the top of the stack where the object is located; 
	the return value -1 indicates that the object is not on the stack.*/
	
	
	
	
	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public boolean addAll(Collection<? extends E> c) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public E get(int index) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}
