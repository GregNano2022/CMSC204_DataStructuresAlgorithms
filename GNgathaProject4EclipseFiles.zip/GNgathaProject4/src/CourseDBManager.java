import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface<CourseDBElement> {

	private String id;
	private int crn;
	private int credits;
	private String roomNum;
	private String instructor;
	 
	/**
	 * Adds a course (CourseDBElement) with the given information
	 * to CourseDBStructure.
	 * @param id course id 
	 * @param crn course crn
	 * @param credits number of credits
	 * @param roomNum course room number
	 * @param instructor name of the instructor
	 */
	
	 
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		this.id=id;
		this.crn=crn;
		this.credits=credits;
		this.roomNum=roomNum;
		this.instructor=instructor;
		ArrayList<String>CourseDBElement = new ArrayList<String>();
		//courseList.addAll(credits, courseList);
		CourseDBElement.add(id);
		CourseDBElement.add(roomNum);
		//CourseDBElement.add(crn);
	}
	
	/**
	 * finds  CourseDBElement based on the crn key
	 * @param crn course crn (key)
	 * @return a CourseDBElement object
	 * 
	 */

	public CourseDBElement get(int crn) {
		this.crn=crn;
		//int element = crn;
		return new CourseDBElement() ;
	}
	
	/**
	 * Reads the information of courses from a test file and adds them
	 * to the CourseDBStructure data structure
	 * @param input input file 
	 * @throws FileNotFoundException if file does not exists
	 */
	public void readFile(File input) throws FileNotFoundException {
		// TODO Auto-generated method stub
				ArrayList <String>CourseDBElement = new ArrayList<String>();
				
		//We use the BufferedReader Java Application to read the text file
						try {
							BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\terpn\\OneDrive\\Documents\\CMSC204\\Assignments\\Project4\\4C-Release\\courses-S23.txt"));
							String line = reader.readLine();
							
							// Read file until reader has no characters/items to read
							while((line=reader.readLine()) != null) {
							String[] courseInfo = line.split("");
							if(courseInfo.length >1) {
								String courseCrn = courseInfo[0];
								String courseID =courseInfo[1];
								String courseID2 =courseInfo[2];
							//System.out.println(courseInfo);
							System.out.println(courseCrn + " "+  courseID );
							}
								//Split sentence into an array of words when reader encounters a space 
							//CourseDBElement.[] CourseDBEelement = line.split(id);
							//String courseID = line.trim();
							//String courseCRN = CourseDBElement[1].tim();
							//System.out.println("courseDBE"+CourseDBEelement);
							//System.out.println("courseDBE"+courseID);
							 
			//	try
				//{
				//	File file = new File("C:\\Users\\terpn\\OneDrive\\Documents\\CMSC204\\Assignments\\Project4\\4C-Release\\courses-S23.txt");
				//	Scanner inputFile = new Scanner(file);
					//Use Buffered reader to read file
				//Open the file for reading
					//BufferedReader CourseDBStrucure = new BufferedReader(new FileReader(""));
				//	String line = CourseDBStructure.readLine();
					
					// Read file until reader has no characters/items to read
					//while((line=CourseDBStructure.readLine()) != null) 
				//	while(inputFile.hasNext())	
					//{
						
						//String course =inputFile.nextLine();
						//String[] courseSplit =course.split(", ");
						//ArrayList<String> courseSplitArray=new ArrayList<String>();
						//System.out.println(courseInfo);
					
							}
				//Close the reader
			//	CourseDBStructure.close();
			reader.close();
							
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}
	/**
	 * @return an array list of string representation of each course in 
	 * the data structure separated by a new line. 
	 * Refer to the following example:
	 * Course:CMSC500 CRN:39999 Credits:4 Instructor:Nobody InParticular Room:SC100
	 * Course:CMSC600 CRN:4000 Credits:4 Instructor:Somebody Room:SC200
	 */
	public ArrayList<String> showAll() {
		ArrayList<String>CourseDBElement = new ArrayList<String>();
		
		Arrays.asList(CourseDBElement);
		
		for (String courses : CourseDBElement) {
			System.out.println(CourseDBElement);
		return  CourseDBElement;
	}
		return CourseDBElement;
		
}
}
