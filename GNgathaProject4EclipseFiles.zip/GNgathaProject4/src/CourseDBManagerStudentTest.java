import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CourseDBManagerStudentTest {
	private static CourseDBManagerInterface<?> StudentDataMgr = new CourseDBManager();

	/**
	 * Create an instance of CourseDBManager
	 * @throws Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		StudentDataMgr = new CourseDBManager();
	}
	/**
	 * Set StudentdataMgr reference to null
	 * @throws Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		StudentDataMgr = null;
	}
	/**
	 * Testing for the createConcordanceArray method
	 * Using the String text created in setUp()
	 */
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	/**
	 * Testing for the createConcordanceArray method
	 * Using the String text created in setUp()
	 */
	@Test
	public void testAddToDB() {
			try {
				StudentDataMgr.add("CMSC203",30504,4,"SC450","Joey Bag-O-Donuts");
				StudentDataMgr.add("CMSC204", 30599, 4, "RM102", "Robert James");
				StudentDataMgr.add("Chemistry200", 5,  4300, "Rm304", "Mary Anne");
			}
			catch(Exception e) {
				fail("This should not have caused an Exception");
			}
		
	}

}
