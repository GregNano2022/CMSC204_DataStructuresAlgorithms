import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.LinkedList;

public class CourseDBStructure {

	
	
	private int TableSize;
	private int crn;
	private String s;
	private static final int CAPACITY = 500;
	
	CourseDBStructure(String string, int i){
		
	}
	
	public CourseDBStructure(int i) {
		// TODO Auto-generated constructor stub
	}

	/** 
	* Adds a CourseDBElement object to the CourseDBStructure using the hashcode
	* of the CourseDatabaseElemen object's crn value.
	* If the CourseDatabaseElement already exists, exit quietly
	*  
	* @param element the CourseDBElement to be added to CourseDBStructure
	*/
	
	public void add(CourseDBElement element) {
		
		int hash = hashFunction(element);
		if (element==null) {
			LinkedList<Integer>courses = new LinkedList<Integer>();
		courses.add(crn, hash);
		}
	}
	
	private int hashFunction(CourseDBElement element) {
		// TODO Auto-generated method stub
		final int JavaStringHashMultiplier = 31;
		int hash = 0;
		int n= s.length();
		for (int i =0; i<n; i++)
		hash = JavaStringHashMultiplier * crn +s.charAt(i);
		return hash;
	}

	/**
	 * Find a courseDatabaseElement based on the key (crn) of the
	 * courseDatabaseElement If the CourseDatabaseElement is found return it If not,
	 * throw an IOException
	 * 
	 * @param crn crn (key) whose associated courseDatabaseElement is to be returned
	 * @return a CourseDBElement whose crn is mapped to the key
	 * @throws IOException if key is not found
	 */

	public CourseDBElement get(int crn) throws IOException {
		this.crn=crn;
		Hashtable<String, Integer> courseList = new Hashtable<String, Integer>();
		int n = courseList.get(s);
		   if (n != 0) {
		     System.out.println( crn);
		   }
		return get(n);
	}

	/**
	 * @return an array list of string representation of each course in 
	 * the data structure separated by a new line. 
	 * Refer to the following example:
	 * Course:CMSC500 CRN:39999 Credits:4 Instructor:Nobody InParticular Room:SC100
	 * Course:CMSC600 CRN:4000 Credits:4 Instructor:Somebody Room:SC200
	 */
	
	public ArrayList<String> showAll() {
		ArrayList<String>CourseDBElement = new ArrayList<String>();
				
		//Arrays.asList(CourseDBElement);
		
		for (String s : CourseDBElement) {
			System.out.println(CourseDBElement);
		return CourseDBElement;
	}
		return CourseDBElement;
	}
	/**
	* Returns the size of the ConcordanceDataStructure (number of indexes in the array)
	*/
	public int getTableSize() {
		return TableSize;
	}
	

}


	

	

	


