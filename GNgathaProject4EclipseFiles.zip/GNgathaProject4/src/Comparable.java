
public interface Comparable {

	public boolean CompareTo(CourseDBElement element);

	boolean CompareTo(Object element);
}
