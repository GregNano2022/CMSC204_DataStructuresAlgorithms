
public class CourseDBElement implements Comparable  {

	


	private String id;
	private int crn;
	private int credits;
	private String roomNum;
	private String instructor;
	private int parseInt;
	private Object o;
	private CourseDBElement element;

	public CourseDBElement(String id, int crn, int credits, String roomNum, String instructor)
	{
		
		this.id=id;
		this.crn=crn;
		this.credits=credits;
		this.roomNum=roomNum;
		this.instructor=instructor;
		
	}

	public CourseDBElement() {
		// TODO Auto-generated constructor stub
		
	}

	public  int getCRN() {
		// TODO Auto-generated method stub
		return credits  ;
	}

	public Object getID() {
		// TODO Auto-generated method stub
		return id;
	}

	public void setCRN(int parseInt) {
		this.parseInt=parseInt;
	}

	

	@Override
	public boolean CompareTo(CourseDBElement element) {
		// TODO Auto-generated method stub
		this.element=element;
		return false;
	}

	@Override
	public boolean CompareTo(Object element) {
		// TODO Auto-generated method stub
		return false;
	}

	public Object getRoomNum() {
		// TODO Auto-generated method stub
		return null;
	}



}
