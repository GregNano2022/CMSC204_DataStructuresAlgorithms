import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Notation {

	private static Character val1=' ';
	private static Character val2=' ';
	private static String val3=" ";
	private static double result=0.0;
	private static Object val4;
	private static String Infix;
	private static char C;
	private static Double val7=0.0;
	private static Double val8=0.0;
	private static Character val5;
	

	
	
	public static String convertInfixToPostfix(String infix) {
		
		// TODO Auto-generated method stub
		//Infix expression to postfix expression:
		
		//Create a queue to hold postfix expression from infix
	Queue<Character> queue = new LinkedList<>();
	String Postfix =" ";
	//Create a Stack to hold operands
		Stack<Character> stack = new Stack<>();
		
		//Read the infix expression from left to right and do the following: 
	for (int i = 0; i <infix.length(); i++)
	{
		char C= infix.charAt(i);
	
		//If the current character in the infix is a space, ignore it.
		if (C == ' ')continue; 
			
		 
		//If the current character in the infix is a digit, copy it to the postfix solution queue
		else if ( Character.isDigit(C)) {
			queue.add(C);
		}
		//If the current character in the infix is a left parenthesis, push it onto the stack
		else if (C == '(') {
			stack.push(C);
		}
		//If the current character in the infix is an operator, 
		//1.Pop operators (if there are any) at the top of the stack while they have 
			//equal or higher precedence than the current operator, and insert the 
		   //popped operators in postfix solution queue
		//2.Push the current character in the infix onto the stack 
		else if (isOperator(C)) {
		while(!stack.isEmpty()&& stack.peek()== '(' && precedence (C)<= precedence(stack.peek()))
       {
		queue.add(stack.pop())	;
       }
		}	
			//If the current character in the infix is a right parenthesis 
		else if (C == ')') {
			//1.Pop operators from the top of the stack and insert them in postfix solution queue
			//until a left parenthesis is at the top of the stack, 
			while (!stack.isEmpty() && stack.peek()!= '(')
				queue.add(stack.pop());
			//if no left parenthesis-throw an error
			if (C!= '(')
				System.out.println("No left Parenthesis");
		
		
		//2.Pop (and discard) the left parenthesis from the stack 
	queue.remove('(');
	
		}
	
			//When the infix expression has been read, 
		    //Pop any remaining operators and insert them in postfix solution queue.
			while(!stack.isEmpty()) {
				queue.add(stack.pop());
			}
			
	}
	return queue.toString()   ;
	}

	
	
	
private static int precedence(char c) {
		// TODO Auto-generated method stub
	if (c == '^') {
		return 2;                  //highest precedence
	}
		else if (c == '*' || c == '/'){ // 2nd highest precedence 
			return 1;
	}
		else if ( c =='+' || c =='-')   //lowest precedence
			return 0;
	return c;                      
	}
//Check if Character C is an operator
	private static boolean isOperator(char c) {
		// TODO Auto-generated method stub
		return c == '+' || c == '-' || c=='*' || c== '/' || c == '%';
	
	}

	public static String convertPostfixToInfix(String postfix) {
		
		postfix =" ";
		//Create a Stack to hold operands
				Stack<Character> stack = new Stack<>();
				
				//Create Stack to hold postfix expression
				Stack<String>stack1 = new Stack<>();
				
		//Read the postfix expression from left to right and to the following:
		for (int i = 0; i <postfix.length(); i++)
		{
			
			char C= postfix.charAt(i);
			//If the current character in the postfix is a space, ignore it.
			if (C == ' ')continue; 
			
			//If the current character is an operand, push it on the stack
			if (Character.isDigit(C)) {
				stack.push(C);
			}
			//If the current character is an operator,
			//1.Pop the top 2 values from the stack.
			//If there are fewer than 2 values throw an error
			if(isOperator(C)) {
			   val1=stack.pop();
				val2 = stack.pop();
			}
				else if (C<2) {
					System.out.println("There are fewer than 2 characters"); 
				}
			
			//2.Create a string with 1st value and then the operator and then the 2nd value.
		Stack<String>stack2=new Stack<>();
		    
		  //3.Encapsulate the resulting string within parenthesis
			val3=  "(" +val1 + val2+ ")";
			
			//4.Push the resulting string back to the stack
		
		     stack2.push(val3);
			//When the postfix expression has been read:
			//If there is only one value in the stack – it is the infix string, if more than one 
			//  value, throw an error
          if(stack2.contains(C)&& C<1) {
        	  postfix=stack2.pop();
          }
          else if(C>1) {
        	  System.out.println("Error!Stack has more than one value");
          }
          
		}
		return postfix.toString() ;
	
	
	
		}

	

	public static double evaluatePostfixExpression(String postfixExpr) {
		// TODO Auto-generated method stub
	
		
		//Stack to hold postfixExpr 
		Stack<Double> stack = new Stack<>();
		
		//Read the postfix expression from left to right and to the following:
		for (int i = 0; i <postfixExpr.length(); i++)
		{
			 C= postfixExpr.charAt(i);
			//If the current character in the postfix is a space, ignore it.
			if (C == ' ')continue; 
			
			//If the current character is an operand or left parenthesis, push on the stack
			if(isOperand(C)|| C =='(') {
				stack.push((double) C);
			}
			//If the current character is an operator,
			//1.Pop the top 2 values from the stack. If there are fewer than 2 values throw an error
			if(isOperator(C)) {
				  val7=stack.pop();
				 val8 = stack.pop();
				 
			}
				else if (C<2) {
					System.out.println("There are fewer than 2 characters"); 
				}
			//2.Perform the arithmetic calculation of the operator with the first popped value 
			//as the right operand and the second popped value as the left operand
			result= (val7+val8);
			//3.Push the resulting value onto the stack
			stack.push(result);
			
			//When the postfix expression has been read:
			//If there is only one value in the stack – it is the result of the postfix expression, if 
			//more than one value, throw an error
			 if(stack.size()==1) {
	        	   stack.pop();
	          }
	          else if(stack.size()>1) {
	        	  System.out.println("Error!Stack has more than one value");
	          }
	          
		}
		 return stack.pop() ; 
		

	}


	private static boolean isOperand(char c) {
		// TODO Auto-generated method stub
		//if(isOperand(c)) {
			return Character.isDigit(c);
	//}
	//	else {
		//	return false;
		}

}



