import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class MyQueue<QueItems, T> implements QueueInterface{

	private ArrayList list;
	private MyQueue queue;
	private String delimiter;
	private Object e;
	private int sizeOfQue;
	private Object head;
	private Object firstEntry;
	private Object lastEntry;
	
	
	/** provide two constructors 
	 * 1. takes an int as the size of the queue
	 * 2. default constructor - uses a default as the size of the queue
	 * 
	 */

	/**
	 * Determines if Queue is empty
	 * @return true if Queue is empty, false if not
	 */
	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		if (queue.isEmpty())
		{
			System.out.println("queue is empty");
			return false;
		}
			else {
				System.out.println("que has items in it");
			}
		return true;
	}
	/**
	 * Determines of the Queue is Full
	 * @return true if Queue is full, false if not
	 */
	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		if (queue.isFull())
		{
			System.out.println("queue is full");
			return true;
		}
			else {
				System.out.println("que has items in it");
			}
		return true;
	}
	
	/**
	 * Deletes and returns the element at the front of the Queue
	 * @return 
	 * @return 
	 * @return the element at the front of the Queue
	 * @throws QueueUnderflowException if queue is empty
	 */
	@Override
	public   Object dequeue() throws QueueUnderflowException {
		// TODO Auto-generated method stub
	

		if (queue.isEmpty()) {
			throw new QueueUnderflowException();
		}
		else {
		firstEntry = queue.firstEntry;
	
		if(firstEntry==null) 
			queue.lastEntry.equals(null);
		
		return firstEntry;  
		}
	}
	/**
	 * Returns number of elements in the Queue
	 * @return the number of elements in the Queue
	 */
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return sizeOfQue;
	}
	/**
	 * Adds an element to the end of the Queue
	 * @param e the element to add to the end of the Queue
	 * @return true if the add was successful
	 * @throws QueueOverflowException if queue is full
	 */
	@Override
	public boolean enqueue(Object e) throws QueueOverflowException {
		// TODO Auto-generated method stub
		this.e=e;
		
		if(queue.isFull()) {
			throw new QueueOverflowException();
		}
		else {
			lastEntry=queue.lastEntry;
			if(lastEntry==null)
				firstEntry=queue.e;
		}
		return false;
		}

	

	/**
	 * Returns the string representation of the elements in the Queue, 
	 * the beginning of the string is the front of the queue
	 * @return string representation of the Queue with elements
	 */
	@Override
	public String toString(String delimiter) {
		return this.delimiter=delimiter;
	
	}
	/**
	  * Fills the Queue with the elements of the ArrayList, First element in the ArrayList
	  * is the first element in the Queue
	  * YOU MUST MAKE A COPY OF LIST AND ADD THOSE ELEMENTS TO THE QUEUE, if you use the
	  * list reference within your Queue, you will be allowing direct access to the data of
	  * your Queue causing a possible security breech.
	  * @param list elements to be added to the Queue
	  * @throws QueueOverflowException if queue is full
	@Override*/
	public void fill(ArrayList list) {
		// TODO Auto-generated method stub
		this.list=list;
		Queue<Integer>queue = new LinkedList<>();
		for (Integer element: queue) {
		queue.add(element);
		}
		
	}

}
