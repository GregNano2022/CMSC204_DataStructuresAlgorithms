import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class MyStack implements StackInterface{

	private ArrayList list;
	private Object e;
	private MyStack stack;
	private Object delimiter;
	private Object top;

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		if (stack.isEmpty())
		{
			System.out.println("Stack is empty");
			return false;
		}
			else {
				System.out.println("Stack has items in it");
			}
		return true;
	}
	

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		if (stack.isFull())
		{
			System.out.println("Stack is Full");
			return true;
		}
			else {
				System.out.println("Stack has no items in it");
			}
		return false;
	}

	@Override
	public Object pop() throws StackUnderflowException {
		// TODO Auto-generated method stub
		Object answer;
	if (top == null)
		throw new StackUnderflowException();
		//if (isEmpty()) {
		//	throw new StackUnderflowException();
	answer = top.getClass();
		//}
	//	else{
			top=top.getClass();
		//}
		return answer;
	}

	@Override
	public Object top() throws StackUnderflowException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0 ;
	}

	@Override
	public boolean push(Object e) throws StackOverflowException {
		// TODO Auto-generated method stub
		this.e=e;
		return false;
	}

	@Override
	public String toString(String delimiter) {
		// TODO Auto-generated method stub
		this.delimiter=delimiter;
		return null;
	}

	@Override
	public void fill(ArrayList list) {
		// TODO Auto-generated method stub
		this.list=list;
		Stack<Integer>stack = new Stack<>();
		stack.addAll(list);
		
		ArrayList<Integer> listOfElements = new ArrayList<>();
		listOfElements.addAll(list);
	}

}
