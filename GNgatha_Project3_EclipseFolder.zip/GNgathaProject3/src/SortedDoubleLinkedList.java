import java.util.Comparator;
import java.util.ListIterator;

/**The Third Class-SortedDoubleLinkedList
A generic sorted double linked list will be constructed using a provided Comparator to
 determine how the list is to be sorted.

/**Implements a generic sorted double list using a provided Comparator. 
 * It extends BasicDoubleLinkedList class.
 * @author GNgatha
 *
 * @param <T>*/
public class SortedDoubleLinkedList<T>extends BasicDoubleLinkedList<T>
{
			


private Comparator<T> compareableObject;
private T data;
private T newEntry;
private int numberOfEntries;
private ListIterator<T> listOfItems;
private T data2;

/**Creates an empty list that is associated with the specified comparator.
* @param compareableObject - Comparator to compare data elements * */
public SortedDoubleLinkedList(Comparator<T> compareableObject)
{
		this.compareableObject=compareableObject;	
}

/**Inserts the specified element at the correct position in the sorted list. 
 * Notice we can insert the same element several times. 
 * Your implementation must traverse the list only once in order
 *  to perform the insertion.
 *  @param data - the data to be added to the list
 */
	
public void add​(T data)
{
	
		
	Node newNode = new Node(data);
	Node nodeBefore = getNodeBefore(data);
	
	if(isEmpty() || (nodeBefore == null))
	{
		//Add at Beginning
		newNode.setNextNode(head);
		head = newNode;
	}
	else
	{
		//Add after nodeBefore
		Node nodeAfter = nodeBefore.getNextNode();
		newNode.setNextNode(nodeAfter);
		nodeBefore.setNextNode(newNode);
	}// end if
	numberOfEntries++;
} //end add
	

		
private BasicDoubleLinkedList<T>.Node getNodeBefore(T data2) {
	this.data2=data2;
	return null;
}

private boolean isEmpty() {
	// TODO Auto-generated method stub
	return false;
}

/**This operation is invalid for a sorted list. 
 * An UnsupportedOperationException will be generated using the message 
 * "Invalid operation for sorted list."
 @override addToEnd in class BasicDoubleLinkedList<T>
@param data - the data for the Node within the linked list
@throws java.lang.UnsupportedOperationException - if method is called */

@Override
public void addToEnd​(T data) throws java.lang.UnsupportedOperationException
{
		this.data=data;
}
/**This operation is invalid for a sorted list.
 * @throws  An UnsupportedOperationException will be generated using the message "Invalid operation for sorted list."
 @Override addToFront in class BasicDoubleLinkedList<T>
@param data - the data for the Node within the linked list
@throws UnsupportedOperationException - if method is called*/

@Override
public void addToFront​(T data) throws UnsupportedOperationException
{
	this.data=data;
}
/**Implements the iterator by calling the super class iterator method.
@specified Specified by:iterator in interface java.lang.Iterable<T>
@override iterator in class BasicDoubleLinkedList<T>
@return an iterator positioned at the head of the list*/

@Override
public ListIterator<T> iterator()
{
	
	return iterator() ;
	
	

}
/**Implements the remove operation by calling the super class remove method.
@override remove in class BasicDoubleLinkedList<T>
@param data - the data element to be removed
@compare the comparator to determine equality of data elements
@return a node containing the data or null*/

@Override
public BasicDoubleLinkedList.Node remove​(T data, Comparator<T> comparator)
{
	this.data = data;
	this.comparator = comparator;
	return head;
	
}

public void add(String newElement) {
	// TODO Auto-generated method stub
	
}
}
