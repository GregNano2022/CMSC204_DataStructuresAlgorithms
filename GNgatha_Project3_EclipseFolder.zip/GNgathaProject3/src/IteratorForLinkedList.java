import java.util.Iterator;

public class IteratorForLinkedList<T> implements Iterator<T> {

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T next() {
		// TODO Auto-generated method stub
		return null;
	}

}
