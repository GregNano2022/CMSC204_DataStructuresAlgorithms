import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;


/**This generic double-linked list that implements the Iterable interface 
 * and relies on a head (reference to first element of the list) and tail 
 * (reference to the last element of the list). 
 * Both are set to null when the list is empty. 
 * Both point to the same element when there is only one element in the list.
 *  The class must only define the following entities:
 *  1) an inner class Node, The inner Node class has only three fields:
 *   data, the prev and next references.
 	*2) an inner class named DoubleLinkedListIterator that implements ListIterator 
(for the iterator method), This inner class implements only the hasNext(), next(), hasPrevious() and previous() methods of ListIterator , all other methods can throw the UnsupportedOperationException:

All the entities are defined as protected so they can be accessed by the subclasses.
 * @author Gngatha
 *
 * @param <T>
 */

public class BasicDoubleLinkedList <T> extends Object implements Iterable<T> {
	protected int size;
	//protected T data;
	
	protected Node head;
	protected Node tail;
	protected T FirstElement;
	protected T LastElement;
	protected T FirstNode;
	protected T LastNode;
	protected Object a;
	protected Comparator<T> comparator;
	public BasicDoubleLinkedList<T>.Node next;
	public T list;

	/**Inner Class Node
	
	/**1.**Inner Class Node-Has only three fields data, the prev and next references.*/
public class Node
{
	
	Node prev;
	Node next;
	
	public Node(T data) {
		// TODO Auto-generated constructor stub
	}
	public void setNextNode(BasicDoubleLinkedList<T>.Node head) {
		this.next=head;
		
	}
	public BasicDoubleLinkedList<T>.Node getNextNode() {
		return getNextNode();
		
	}
	public T getData() {
		// TODO Auto-generated method stub
		return getData();
	}

		
}
	

/**Constructor to set to initialize head, tail and size to null, null and 0*/
  public BasicDoubleLinkedList()
  {
	  head = null; 
	  tail=null; 
	  size = 0;
	  
  }
	
/** @return Returns the number of nodes in the list.	
Does not traverse the list to compute the size. This method just returns the value 
of the instance variable you use to keep track of size.
@return Returns the size of the linked list*/
public  int getSize()
{
 return size;	
}

/**Adds an element to the end of the list and updated the size of the list
DO NOT use iterators to implement this method.
@return data - the data to be added to the list*/

	
public void addToEnd​(T data)
{
	//create new node
	Node newNode = new Node(data);
	
	//find tail end and add to tail end of list
	if (isEmpty())
		head = newNode;
	else
	{
		Node tail =getNodeAt(size);
		tail.setNextNode(newNode);
	}//end if
	size++;
}//end add
	


private boolean isEmpty() {
	boolean result;
	if(size ==0)
	{
		result = true;
	}
	else
	{
		result= false;
	}
	return result;
}

private Node getNodeAt(int givenPosition) {
	Node currentNode = head;
	
	for (int counter = 1; counter <givenPosition; counter++)
		currentNode = currentNode.getNextNode();
	
	return currentNode;
	
}

/**Adds element to the front of the list and updates the size of the list
 * Do not use iterators to implement this method.
 * @param the data to be added to the list*/
public void addToFront​(T data)
{
	//create new node
		Node newNode = new Node(data);
		
		//find tail end and add to tail end of list
		if (isEmpty())
			tail = newNode;
		else
		{
			head.setNextNode(newNode);
			head =newNode;
			size++;
	
		}
}

/**Returns but does not remove the first element from the list.
 * @return  return data element or null  
 * If there are no elements the method returns null.
 * Do not implement this method using iterators.*/
public T getFirst()
{
if(size == 0)
	return null;
else
	return FirstElement;
	
}

/**Returns but does not remove the last element from the list.
If there are no elements the method returns null.
 Do not implement this method using iterators.
@return Returns:the data element or null If there are no elements the method returns null.
 */
public T getLast()
{
	if (size ==0)
		return null;
	return LastNode;
}

/**This method returns an object of the DoubleLinkedListIterator. 
 * (the inner class that implements java's ListIterator interface)
Specified by: iterator in interface Iterable<T>
@return Returns: a ListIterator object*/

public ListIterator <T> iterator() {
	
	return new IteratorForDoubleLinkedList<T>();
}
/**Removes the first instance of the targetData from the list. 
Notice that you must remove the elements by performing a single traversal over the list. 
You may not use any of the other retrieval methods associated with the class in order to 
complete the removal process. You must use the provided comparator (do not use equals) to 
find those elements that match the target. Do not implement this method using iterators.
@parameter targetData - the data element to be removed
@comparator comparator - the comparator to determine equality of data elements
@return Returns:a node containing the targetData or null
*/

public Node remove​(T targetData, Comparator<T> comparator)
{

	this.FirstElement = targetData;
	this.comparator = comparator;
	return head ;
	
	
	
}
/**Removes and returns the first element from the list. 
 * If there are no elements the method returns null. 
 * Do not implement this method using iterators.
 * @return
 */
public T retrieveFirstElement()
{
	if (isEmpty())
	return FirstElement;
	return FirstElement;

}
/**Removes and returns the last element from the list.
 *  If there are no elements the method returns null.
 */
public T retrieveLastElement()
{
	if(size == 0)
		 return null ;
	else
	{
	return LastElement;
}
}
/**Returns an arraylist of all the items in the Double Linked list*/
public ArrayList<T> toArrayList()
{
	
	ArrayList<T> List = new ArrayList<>();
	//for (int i=0; FirstElement !=null; i++)
	
	List.add(FirstElement);
	return List;
	
   
}


	
	/**Second Class
	/*2) an inner class named DoubleLinkedListIterator that implements ListIterator 
	(for the iterator method), This inner class implements only the hasNext(), next(), 
	hasPrevious() and previous() methods of ListIterator , all other methods can throw 
	the UnsupportedOperationException:*/

 class  DoubleLinkedListIterator extends java.lang.Object 
implements java.util.ListIterator<T>{

		
private int nextIndex;
/**Constructor to initialize the current pointer to the head of the BasicDoubleLinkedList.
The other attributes defined for this class can be initialized as well.*/
public DoubleLinkedListIterator()
{
	next=head;
}
/**Specified by:hasNext in interface java.util.Iterator<T>
Specified by:hasNext in interface java.util.ListIterator<T>*/
public boolean hasNext()
{
	return next != null;
			
}
/**Specified by:next in interface java.util.Iterator<T>
@throws Throws:java.util.NoSuchElementException */
public T next() throws NoSuchElementException{
	T data;
	
	if(hasNext())
	{
		data = next.getData();
		next = next.getNextNode();
	}
	else
		throw new NoSuchElementException();
	return data;
		
		}
/**Specified by:hasPrevious in interface java.util.ListIterator<T> */
 public boolean hasPrevious() {
	return false;
	 
 }
 /**Specified by:previous in interface java.util.ListIterator<T>
@throws Throws:java.util.NoSuchElementException */
 public T previous() throws NoSuchElementException{
	 
	return LastElement;
	 
 }
 /**Specified by:remove in interface java.util.Iterator<T>
Specified by:remove in interface java.util.ListIterator<T>
@throws Throws:java.lang.UnsupportedOperationException*/
 public void remove() throws UnsupportedOperationException{
	 
 }
 /**Specified by: add in interface java.util.ListIterator<T>
@throws Throws: java.lang.UnsupportedOperationException */
 public void add​(T arg0) throws UnsupportedOperationException{
 }
 /**Specified by:nextIndex in interface java.util.ListIterator<T>
@throws Throws:java.lang.UnsupportedOperationException*/

 public int nextIndex() throws UnsupportedOperationException{
	 return nextIndex;
 }
 /**Specified by:previousIndex in interface java.util.ListIterator<T>
@throws Throws:java.lang.UnsupportedOperationException*/
 public int previousIndex() throws UnsupportedOperationException{
	 return previousIndex();
 }
 /**Specified by:set in interface java.util.ListIterator<T>
Throws:java.lang.UnsupportedOperationException*/
 public void set​(T arg0) throws UnsupportedOperationException{
 }
@Override
public void set(T e) {
}
@Override
public void add(T e) {
		
}


	public void remove(String newElement2, DoubleLinkedListDriver.StringComparator sComp) {
		// TODO Auto-generated method stub
		
	}

	public void addToFront(String newElement) {
		// TODO Auto-generated method stub
		
	}

	public void addToEnd(String newElement) {
		// TODO Auto-generated method stub
		
	}
}


	public void addToFront(String newElement) {
		// TODO Auto-generated method stub
		
	}

	public void addToEnd(String newElement) {
		// TODO Auto-generated method stub
		
	}

}
	

