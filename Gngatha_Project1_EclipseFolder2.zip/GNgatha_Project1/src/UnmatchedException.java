
public class UnmatchedException extends Exception {

}
