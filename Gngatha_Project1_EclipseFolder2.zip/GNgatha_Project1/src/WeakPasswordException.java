
public class WeakPasswordException extends Exception {

}
