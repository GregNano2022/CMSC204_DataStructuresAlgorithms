/**
 * Thrown if Length of password is less than 6 characters .
 * @author George
 */
public class LengthException extends Exception {
	/**
	 * Constructor.
	 */
	public LengthException() {
		this("The password must be at least 6 characters long");
	}
	
	/**
	 * Parameterized constructor.
	 * @param message String message to be shown.
	 */
	public LengthException(String message) {
		super(message);
	}
}
