
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
/**
 * STUDENT tests for the methods of PasswordChecker
 * @author 
 *
 */
public class PasswordCheckerTest_STUDENT {
	ArrayList<String> passwords;
	String password1, password2;
	
	@Before
	public void setUp() throws Exception {
		passwords = new ArrayList<String>();
	}

	@After
	public void tearDown() throws Exception {
		passwords = null;
	}

	/**
	 * Test if the password is less than 6 characters long.
	 * This test should throw a LengthException for second case.
	 */
	@Test
	public void testIsValidPasswordTooShort()
	{
		try
		{
		assertTrue(PasswordCheckerUtility.isValidPassword​TooShort("WtX4"));
		}
		catch(LengthException e)
		{
			assertTrue("Successfully threw a lengthExcepetion",true);
		}
		catch(Exception e)
		{
			assertTrue("Threw some other exception besides lengthException",false);
			System.out.println("hello");
		}
	}
	/**
	 * Test if the password has at least one uppercase alpha character
	 * This test should throw a NoUpperAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoUpperAlpha()
	{
		try
		{
		assertTrue(PasswordCheckerUtility.isValidPasswordNoUpperAlpha(passwords));
		}
		catch(LengthException e)
		{
			assertTrue("Successfully threw a InvalidPassowrdExcepetion",true);
		}
		catch(Exception e)
		{
			assertTrue("Threw some other exception besides InvalidPasswordException",false);
			System.out.println("hello");
		}
	}
	/**
	 * Test if the password has at least one lowercase alpha character
	 * This test should throw a NoLowerAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoLowerAlpha()
	{
		try
		{
		Assert.assertTrue(PasswordCheckerUtility.isValidPasswordNoLowerAlpha(passwords));
		}
		catch(LengthException e)
		{
			assertTrue("Successfully threw a InvalidPasswordExcepetion",true);
		}
		catch(Exception e)
		{
			assertTrue("Threw some other exception besides InvalidPasswordException",false);
			System.out.println("line 49");
			
		}
	}
	/**
	 * Test if the password has more than 2 of the same character in sequence
	 * This test should throw a InvalidSequenceException for second case
	 */
	@Test
	public void testIsWeakPassword()
	{
		try
		{
		PasswordCheckerUtility.isWeakPassword(passwords);
		}
		catch(LengthException e)
		{
			assertTrue("Successfully threw a InvalidPasswordException",true);
		}
		catch(Exception e)
		{
			assertTrue("Threw some other exception besides InvalidPasswordException",false);
			System.out.println("line 49");
		}
	/**
	 * Test if the password has more than 2 of the same character in sequence
	 * This test should throw a InvalidSequenceException for second case
	 */
	@Test
	public void testIsValidPasswordInvalidSequence()
	{
		try
		{
		assertTrue(PasswordCheckerUtility.isValidPasswordInvalidSequence(passwords));
		}
		catch(LengthException e)
		{
			assertTrue("Successfully threw a lengthExcepetion",true);
		}
		catch(Exception e)
		{
			assertTrue("Threw some other exception besides lengthException",false);
			System.out.println("line 49");
		}
	}
	
	/**
	 * Test if the password has at least one digit
	 * One test should throw a NoDigitException
	 */
	@Test
	public void testIsValidPasswordNoDigit()
	{
		try
		{
		assertTrue(PasswordCheckerUtility.isValidPasswordNoDigit(passwords));
		}
		catch(LengthException e)
		{
			assertTrue("Successfully threw a lengthExcepetion",true);
		}
		catch(Exception e)
		{
			assertTrue("Threw some other exception besides lengthException",false);
			System.out.println("line 49");
			
		}
	}
	
	/**
	 * Test correct passwords
	 * This test should not throw an exception
	 */
	@Test
	public void testIsValidPasswordSuccessful()
	{
		try
		{
		assertTrue(PasswordCheckerUtility.isValidPasswordNoDigit(passwords));
		}
		catch(LengthException e)
		{
			assertTrue("Successfully threw a lengthExcepetion",true);
		}
		catch(Exception e)
		{
			assertTrue("Threw some other exception besides lengthException",false);
			System.out.println("line 49");
		}
	}
	

	/**
	 * Test the invalidPasswords method
	 * Check the results of the ArrayList of Strings returned by the validPasswords method
	 */
	@Test
	public void testInvalidPasswords() {
		try
		{
		assertTrue(PasswordCheckerUtility.invalidPasswords("qgtyunvd1"));
		}
		catch(Exception e)
		{
			assertTrue("Threw some other exception besides lengthException",false);
			System.out.println("hello2");
			
		}
	}
	
}
