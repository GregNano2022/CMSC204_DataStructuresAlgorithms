import java.util.ArrayList;

public class TreeNode<String> extends Object{
	private String dataNode;
	private String TreeNodedata;
	private TreeNode<String> node;
	private Object leftChild;
	private Object rightChild;
	
	/**Create a new TreeNode with left and right child set to null and data set to the dataNode
	@param dataNode - the data to be stored in the TreeNode*/
	public TreeNode(String dataNode) {
		this.leftChild=null;
		this.rightChild=null;
		this.dataNode=dataNode;
		
		
	}
	/**used for making deep copies
@param node - node to make copy of 
	 * @return */
	public TreeNode(TreeNode<String> node) {
		this.TreeNodedata=node.getData();
		this.leftChild=node.leftChild;
		this.rightChild=node.rightChild;
	}
	/**Return the data within this TreeNode
	Returns:the data within the TreeNode*/
	public String getData() {
		return TreeNodedata ;
		
	}
}
