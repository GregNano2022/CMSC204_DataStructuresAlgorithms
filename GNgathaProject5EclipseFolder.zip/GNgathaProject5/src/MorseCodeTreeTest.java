import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class MorseCodeTreeTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testConvertToEnglishString() {

		String converter1 = MorseCodeConverter.convertToEnglish​("- .... .. ... / .. ... / .- / - . ... - / ..-. --- .-. / .--. .-. --- .--- . -.-. - / .....");
	assertEquals("this is a test for project5",converter1);
	}

}
