import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;



public class TownGraphManager_STUDENT_Test {
	private TownGraphManager graph;
	private String[] town;


	
		//assertEquals("Not yet implemented");
	
	@Before
	public void setUp() throws Exception {
		  graph = new TownGraphManager();
		  town = new String[15];
		  
		  for (int i = 1; i < 15; i++) {
			  town[i] = "Town_" + i;
			  graph.addTown(town[i]);
		  }
		  
		  graph.addRoad(town[1], town[2], 2, "Road_A");
		  graph.addRoad(town[1], town[3], 4, "Road_B");
		  graph.addRoad(town[1], town[5], 6, "Road_C");
		  graph.addRoad(town[3], town[7], 1, "Road_D");
		  graph.addRoad(town[3], town[8], 2, "Road_E");
		  graph.addRoad(town[4], town[8], 3, "Road_F");
		  graph.addRoad(town[6], town[9], 3, "Road_G");
		  graph.addRoad(town[9], town[10], 4, "Road_H");
		  graph.addRoad(town[8], town[10], 2, "Road_1");
		  graph.addRoad(town[5], town[10], 5, "Road_J");
		  graph.addRoad(town[10], town[11], 3, "Road_K");
		  graph.addRoad(town[2], town[11], 6, "Road_L");
		  graph.addRoad(town[5], town[10], 5, "Road_M");
		  graph.addRoad(town[10], town[11], 3, "Road_N");
		  graph.addRoad(town[2], town[11], 6, "Road_O");
	}

	@After
	public void tearDown() throws Exception {
		graph = null;
	}

	@Test
	public void testAddRoad() {
		ArrayList<String> roads = graph.allRoads();
		assertEquals("Road_A", roads.get(0));
		assertEquals("Road_B", roads.get(1));
		assertEquals("Road_C", roads.get(2));
		assertEquals("Road_D", roads.get(3));
		graph.addRoad(town[4], town[11], 1,"Road_O");
		roads = graph.allRoads();
		assertEquals("Road_A", roads.get(0));
		assertEquals("Road_B", roads.get(1));
		assertEquals("Road_C", roads.get(2));
		assertEquals("Road_D", roads.get(3));
		assertEquals("Road_E", roads.get(4));
		
	}

	@Test
	public void testGetRoad() {
		assertEquals("Road_C", graph.getRoad(town[2], town[11]));
		assertEquals("Road_D", graph.getRoad(town[3], town[7]));
	}

	@Test
	public void testAddTown() {
		assertEquals(false, graph.containsTown("Town_K"));
		graph.addTown("Town_K");
		assertEquals(true, graph.containsTown("Town_K"));
	}
	
	

	@Test
	public void testAllRoads() {
		ArrayList<String> roads = graph.allRoads();
		assertEquals("Road_A", roads.get(0));
		assertEquals("Road_B", roads.get(1));
		assertEquals("Road_C", roads.get(2));
		assertEquals("Road_D", roads.get(10));
		assertEquals("Road_E", roads.get(11));
	}

	
	@Test
	public void testAllTowns() {
		ArrayList<String> roads = graph.allTowns();
		assertEquals("Town_A", roads.get(0));
		assertEquals("Town_B", roads.get(1));
		assertEquals("Town_C", roads.get(2));
		assertEquals("Town_D", roads.get(3));
		assertEquals("Town_E", roads.get(9));
	}

	@Test
	public void testGetPath() {
		ArrayList<String> path = graph.getPath(town[1],town[11]);
		  assertNotNull(path);
		  assertTrue(path.size() > 0);
		  assertEquals("Town_1 via Road_A to Town_2 2 mi",path.get(0).trim());
		  assertEquals("Town_2 via Road_M to Town_11 6 mi",path.get(1).trim());

	}
	
	
}


