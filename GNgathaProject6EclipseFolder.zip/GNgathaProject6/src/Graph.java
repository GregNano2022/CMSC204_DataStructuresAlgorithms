import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class Graph implements GraphInterface<Town, Road>{

	private Town sourceVertex;
	private Town destinationVertex;
	private int weight;
	private String description;
	private Town v;
	private Graph GraphEdge;
	private HashMap TownToRoads;
	private HashMap<Town, Road> towns;
	private HashSet<Road> roads;
	private Road[] edge;
	private Town edges;
	private HashMap priorPosition;
	//Create an Empty Graph
	public Graph() {
		towns= new HashMap<Town, Road>();
		roads= new HashSet<Road>();
	}

	 /**
     * Returns an edge connecting source vertex to target vertex if such
     * vertices and such edge exist in this graph. Otherwise returns
     * null. If any of the specified vertices is null
     * returns null
     *
     * In undirected graphs, the returned edge may have its source and target
     * vertices in the opposite order.
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     *
     * @return an edge connecting source vertex to target vertex.
     */
	@Override
	public Road getEdge(Town sourceVertex, Town destinationVertex) {
		// TODO Auto-generated method stub
		this.sourceVertex=sourceVertex;
		this.destinationVertex=destinationVertex;
		if(sourceVertex == null || destinationVertex ==null) {
			return null;
		}
		for(Road road :roads) {
		if(road.contains(sourceVertex)&& road.contains(destinationVertex)){
			return road;
		}
		}
			return null;
			
		}
		
	
	  /**
     * Creates a new edge in this graph, going from the source vertex to the
     * target vertex, and returns the created edge. 
     * 
     * The source and target vertices must already be contained in this
     * graph. If they are not found in graph IllegalArgumentException is
     * thrown.
     *
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     * @param weight weight of the edge
     * @param description description for edge
     *
     * @return The newly created edge if added to the graph, otherwise null.
     *
     * @throws IllegalArgumentException if source or target vertices are not
     * found in the graph.
     * @throws NullPointerException if any of the specified vertices is null.
     */
	@Override
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description)
	{
		// TODO Auto-generated method stub
		this.sourceVertex=sourceVertex;
		this.destinationVertex=destinationVertex;
		this.weight=weight;
		this.description=description;
		if(sourceVertex == null || destinationVertex == null || weight <0 || description == null) {
			throw new NullPointerException();
		}
		else if(!Town.contains(sourceVertex) || !Town.contains(destinationVertex)) {
			throw new IllegalArgumentException();
		}
		
		Road road = new Road (sourceVertex, destinationVertex, weight, description);
		sourceVertex.getRoads().add(road);
		destinationVertex.getRoads().add(road);
		return road;
	}
	
	 /**
     * Adds the specified vertex to this graph if not already present. More
     * formally, adds the specified vertex, v, to this graph if
     * this graph contains no vertex u such that
     * u.equals(v). If this graph already contains such vertex, the call
     * leaves this graph unchanged and returns false. In combination
     * with the restriction on constructors, this ensures that graphs never
     * contain duplicate vertices.
     *
     * @param v vertex to be added to this graph.
     *
     * @return true if this graph did not already contain the specified
     * vertex.
     *
     * @throws NullPointerException if the specified vertex is null.
     */
	@Override
	public boolean addVertex(Town v) {
		// TODO Auto-generated method stub
		this.v=v;
		if(v==null) {
			throw new NullPointerException();
		}
		if(towns.containsValue(v)) {
			return false;
		}
		//towns.add(v);
		return true;
	}
	  /**
     * Returns true if and only if this graph contains an edge going
     * from the source vertex to the target vertex. In undirected graphs the
     * same result is obtained when source and target are inverted. If any of
     * the specified vertices does not exist in the graph, or if is
     * null, returns false.
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     *
     * @return true if this graph contains the specified edge.
     */
	@Override
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
		// TODO Auto-generated method stub
		this.sourceVertex=sourceVertex;
		this.destinationVertex=destinationVertex;
		if(sourceVertex == null || destinationVertex == null) {
			return false;
		}
		for (Road road :edge) {
			if(road.getSource().equals(sourceVertex)&& road.getDestination().equals(destinationVertex))
			{
				return true;
			}
		}
		return false;
	}
	/**
     * Returns true if this graph contains the specified vertex. More
     * formally, returns true if and only if this graph contains a
     * vertex u such that u.equals(v). If the
     * specified vertex is null returns false.
     *
     * @param v vertex whose presence in this graph is to be tested.
     *
     * @return true if this graph contains the specified vertex.
     */
	@Override
	public boolean containsVertex(Town v) {
		// TODO Auto-generated method stub
		this.v=v;
		if(v == null ) {
			return false;
		}
		for (Road road :edge) {
			if(road.getSource().equals(v))
			{
				return true;
			}
		}
		return false;
		
	}
	/**
     * Returns a set of the edges contained in this graph. The set is backed by
     * the graph, so changes to the graph are reflected in the set. If the graph
     * is modified while an iteration over the set is in progress, the results
     * of the iteration are undefined.
     *
     *
     * @return a set of the edges contained in this graph.
     */
	@Override
	public Set<Road> edgeSet() {
		// TODO Auto-generated method stub
		Set<Road> GraphEdges = new HashSet<>();
		for(Town town: GraphEdge.keySet()) {
			for (Road road: GraphEdge.get(town)) {
				if(!GraphEdges.contains(road)) {
			GraphEdges.add(road);
		}
			}
		return GraphEdges;}
		return GraphEdges;
			}
	
	private Town[] keySet() {
		// TODO Auto-generated method stub
		return null;
	}

	private Road[] get(Town town) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
     * Returns a set of all edges touching the specified vertex (also
     * referred to as adjacent vertices). If no edges are
     * touching the specified vertex returns an empty set.
     *
     * @param vertex the vertex for which a set of touching edges is to be
     * returned.
     *
     * @return a set of all edges touching the specified vertex.
     *
     * @throws IllegalArgumentException if vertex is not found in the graph.
     * @throws NullPointerException if vertex is null.
     */
	@Override
	public Set<Road> edgesOf(Town vertex) {
		// TODO Auto-generated method stub
		
		if(vertex==null) {
			return null;
		}
		if(!edges.contains(vertex)) {
			return null;
		}
		for (Road road: edge) {
			if(road.getSource().equals(vertex)||road.getDestination().equals(vertex)) {
				roads.add(road);
			}
		}
		return roads;
	}
	/**
     * Removes an edge going from source vertex to target vertex, if such
     * vertices and such edge exist in this graph. 
     * 
     * If weight >- 1 it must be checked
     * If description != null, it must be checked 
     * 
     * Returns the edge if removed
     * or null otherwise.
     *
     * @param sourceVertex source vertex of the edge.
     * @param destinationVertex target vertex of the edge.
     * @param weight weight of the edge
     * @param description description of the edge
     *
     * @return The removed edge, or null if no edge removed.
     */
	@Override
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, 
			String description) {
		// TODO Auto-generated method stub
		this.sourceVertex=sourceVertex;
		this.destinationVertex=destinationVertex;
		this.weight=weight;
		this.description=description;
		if(sourceVertex == null || destinationVertex ==null) {
			return null;
		}
		for (Road road : edge) {
		if(road.getSource().equals(sourceVertex)&& road.getDestination().equals(destinationVertex)
		&&(weight >-1 || road.getWeight()==weight) && (description == null )){
			{
		roads.remove(road);
			}
		return road;
		}
		}
		return null;
	}
	 /**
     * Removes the specified vertex from this graph including all its touching
     * edges if present. More formally, if the graph contains a vertex 
     * u such that u.equals(v), the call removes all edges
     * that touch u and then removes u itself. If no
     * such u is found, the call leaves the graph unchanged.
     * Returns true if the graph contained the specified vertex. (The
     * graph will not contain the specified vertex once the call returns).
     *
     * If the specified vertex is null returns false.
     *
     * @param v vertex to be removed from this graph, if present.
     *
     * @return true if the graph contained the specified vertex;
     * false otherwise.
     */
	@Override
	public boolean removeVertex(Town v) {
		// TODO Auto-generated method stub
		this.v=v;
		if(towns.remove(v) != null) {
			return true;
		}
		if(v==null) {
			return false;
		}
		return true;
		
	}
	/**
     * Returns a set of the vertices contained in this graph. The set is backed
     * by the graph, so changes to the graph are reflected in the set. If the
     * graph is modified while an iteration over the set is in progress, the
     * results of the iteration are undefined.
     *
     *
     * @return a set view of the vertices contained in this graph.
     */
	@Override
	public Set<Town> vertexSet() {
		// TODO Auto-generated method stub
		Set setVertices= new HashSet();
		for(Road b: roads)
			setVertices.add(b);
		return setVertices;
	}
	 /**
     * Find the shortest path from the sourceVertex to the destinationVertex
     * call the dijkstraShortestPath with the sourceVertex
     * @param sourceVertex starting vertex
     * @param destinationVertex ending vertex
     * @return An arraylist of Strings that describe the path from sourceVertex
     * to destinationVertex
     * They will be in the format: startVertex "via" Edge "to" endVertex weight
	 * As an example: if finding path from Vertex_1 to Vertex_10, the ArrayList<String>
	 * would be in the following format(this is a hypothetical solution):
	 * Vertex_1 via Edge_2 to Vertex_3 4 (first string in ArrayList)
	 * Vertex_3 via Edge_5 to Vertex_8 2 (second string in ArrayList)
	 * Vertex_8 via Edge_9 to Vertex_10 2 (third string in ArrayList)
     */   
	@Override
	public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		// TODO Auto-generated method stub
		this.sourceVertex=sourceVertex;
		this.destinationVertex=destinationVertex;
		
		dijkstraShortestPath(sourceVertex);
		ArrayList<String> ShortestDistance = new ArrayList<>();
		if(priorPosition.containsKey(destinationVertex)) {
		
			Town PresentLocation = destinationVertex;
			while(PresentLocation !=null) {
				ShortestDistance.add(0, PresentLocation.getName());
				PresentLocation=(Town) priorPosition.get(PresentLocation);
			}
		}
		return ShortestDistance ;
	}
	 /**
     * Dijkstra's Shortest Path Method.  Internal structures are built which
     * hold the ability to retrieve the path, shortest distance from the
     * sourceVertex to all the other vertices in the graph, etc.
     * @param sourceVertex the vertex to find shortest path from
     * 
     */
	@Override
	public void dijkstraShortestPath(Town sourceVertex) {
		// TODO Auto-generated method stub
		this.sourceVertex=sourceVertex;
		
	}

	public Town addVertex(String town1) {
		// TODO Auto-generated method stub
		return this.addVertex(town1);
		
	}

}
