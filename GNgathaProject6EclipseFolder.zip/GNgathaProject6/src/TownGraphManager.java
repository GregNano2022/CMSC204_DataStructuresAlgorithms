import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;


public class TownGraphManager implements  TownGraphManagerInterface{

	private String town1;
	private String town2;
	private int weight;
	private String roadName;
	private String v;
	private Graph TownManagerGraph;
	private Object StartVertex;
	private Object endVertex;
	private Graph cityRoads;
	
	public TownGraphManager() {
		 cityRoads = new Graph();
			
	}
	
	/**
	 * Adds a road with 2 towns and a road name
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @param roadName name of road
	 * @return true if the road was added successfully
	 */
	@Override
	public boolean addRoad(String town1, String town2, int weight, String roadName) {
		// TODO Auto-generated method stub
		this.town1=town1;
		this.town2=town2;
		this.weight=weight;
		this.roadName=roadName;
		
		if(cityRoads.addEdge(new Town(town1), new Town (town2), weight, roadName)== null)
		return false ;
		return true;
	
	
		
	}
	/**
	 * Returns the name of the road that both towns are connected through
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return name of road if town 1 and town2 are in the same road, returns null if not
	 */
	@Override
	public String getRoad(String town1, String town2) {
		this.town1=town1;
		this.town2=town2;

		return this.getRoad(town1, town2);
	//	return cityRoads.addVertex(new Town(town1), new Town(town2).getName());
		

	}
/**
	 * Adds a town to the graph
	 * @param v the town's name  (lastname, firstname)
	 * @return true if the town was successfully added, false if not
	 */
	@Override
	public boolean addTown(String v) {
		this.v=v;
		return cityRoads.addVertex(new Town(v));
	}
	/**
	 * Gets a town with a given name
	 * @param name the town's name 
	 * @return the Town specified by the name, or null if town does not exist
	 */
	@Override
	public Town getTown(String name) {
		// TODO Auto-generated method stub
		this.roadName=name;
		//return cityRoads.addVertex(new Town(name));
		return this.getTown(name);
	}
	/**
	 * Determines if a town is already in the graph
	 * @param v the town's name 
	 * @return true if the town is in the graph, false if not
	 */
	@Override
	public boolean containsTown(String v) {
		// TODO Auto-generated method stub
		this.v=v;
		return this.containsTown(v);
	}
	/**
	 * Determines if a road is in the graph
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return true if the road is in the graph, false if not
	 */
	@Override
	public boolean containsRoadConnection(String town1, String town2) {
		// TODO Auto-generated method stub
		this.town1=town1;
		this.town2=town2;
		return this.containsRoadConnection(town1, town2);
	}
	/**
	 * Creates an arraylist of all road titles in sorted order by road name
	 * @return an arraylist of all road titles in sorted order by road name
	 */
	@Override
	public ArrayList<String> allRoads() {
		// TODO Auto-generated method stub
		ArrayList<String> allRoads = new ArrayList<>();
		allRoads.addAll(allRoads);
	/**	String result = "";
		for(String element : allRoads)
		{
			result += element+"\n";
		}
		return allRoads;*/
		return allRoads;
	}
	/**
	 * Deletes a road from the graph
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @param roadName the road name
	 * @return true if the road was successfully deleted, false if not
	 */
	@Override
	public boolean deleteRoadConnection(String town1, String town2, String road) {
		// TODO Auto-generated method stub
		this.town1=town1;
		this.town2=town2;
		this.roadName=road;
		return this.deleteRoadConnection(town1, town2, road);
	}
	/**
	 * Deletes a town from the graph
	 * @param v name of town (lastname, firstname)
	 * @return true if the town was successfully deleted, false if not
	 */
	@Override
	public boolean deleteTown(String v) {
		// TODO Auto-generated method stub
		this.v=v;
		return this.deleteTown(v);
	}
	/**
	 * Creates an arraylist of all towns in alphabetical order (last name, first name)
	 * @return an arraylist of all towns in alphabetical order (last name, first name)
	 */
	@Override
	public ArrayList<String> allTowns() {
		// TODO Auto-generated method stub
		//Create an arraylist of all towns in alphabetical order (last name, first name)
		ArrayList<String> allTowns = new ArrayList<>();
		HashMap<String, String>AllTowns = new HashMap<>();
		AllTowns.put(roadName, roadName);{
		for(String key: AllTowns.keySet())
	//if(key.equals(AllTowns))
		return allTowns ; 
				}
		return allTowns;
	}
	/**
	 * Returns the shortest path from town 1 to town 2
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return an Arraylist of roads connecting the two towns together, null if the
	 * towns have no path to connect them.
	 */
	@Override
	public ArrayList<String> getPath(String town1, String town2) {
		// TODO Auto-generated method stub
		ArrayList<String> getPath= new ArrayList<String>();
		getPath.add(town1);
		getPath.add(town2);
		return getPath ;
	}
	// TODO Auto-generated method stub
				/**
				 * Reads towns from a text file and adds them
				 * @param input input file 
				 * @throws FileNotFoundException if file does not exists
				 */
	@Override
	public void populateTownGraph(File file) throws FileNotFoundException, IOException {
		

							try {
						BufferedReader reader = new BufferedReader(new FileReader(
//"C:\\Users\\terpn\\OneDrive\\Documents\\CMSC204\\Assignments\\Project6\\P6-Release\\MDTowns.txt"));
"C:\\Users\\terpn\\OneDrive\\Documents\\CMSC204\\Assignments\\Project6\\P6-Release\\USTowns.txt"));				
								ArrayList<String>towns = new ArrayList<>();	
			//HashMap<Road, Town> towns = new HashMap<>();
								String line = reader.readLine();
								
								// Read file until reader has no characters/items to read
								while((line=reader.readLine()) != null) {
									towns.add(line);
									line=reader.readLine();
								
									System.out.println(line);
								}
							
								
				reader.close();
								
										} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		}
	
	
}


	
	

