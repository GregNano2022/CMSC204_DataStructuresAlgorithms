import java.util.Set;

/**a Town class that holds the name of the town and a list of adjacent towns*/
public class Town implements Comparable<Town>{

	private Town o;
	private Town templateTown;
	private Object obj;
	private Town town1;
	private String name;
	

	public Town(String name) {
		this.name=name;
		
	}
	public Town(Town templateTown) {
		this.templateTown=templateTown;
	}
	public String getName() {
		return name;
		
	}
	@Override
	public int compareTo(Town o) {
		// TODO Auto-generated method stub
		return this.name.compareTo(o.name) ;
	
	}
		public String toString() {
			return name;
			
		}
		public int hashCode() {
			return 0 ;
			
		}
		public boolean equals(Object obj) {
			return (this==obj);
			
		}
		public static boolean contains1(Town sourceVertex) {
			// TODO Auto-generated method stub
			return false;
		}
		public Set<Road> getRoads() {
			// TODO Auto-generated method stub
			return null;
		}
		public static boolean contains(Town sourceVertex) {
			// TODO Auto-generated method stub
			return false;
		}
}
