/**
	Abstract Data Type for the collection of bids placed by a company.Organizes a companies various bids
	@author George K Ngatha

*/

public interface BidCollection<T>
{

/**
	*Checks Current Number of Bids Placed by the company
	*@return the integer number of bids placed by the company
	*/
public int getNumberBids();

/**
	*Check for number of small(<$5000) bids placed
	*@returns number of small bids
	 */
public int getFrequencySmallBids(T smallBids);

/**
	*Checks for number of large(>$20000) bids placed
	*@returns True if any bids>$20000
	 */
public boolean contains(T largeBids);

/**
	*Adds bid to collection
	*@return True if bid was successfully added or false if not
	*/
public boolean add(T newBid);

/**
	*Removes all small bids 
	*@return True if all small bids removed or false if not.
	*/
public boolean removeSmall(T smallBids);

/**
	*Removes all bids*/
public void clear();

/**
	*Returns all bids ever placed by the company as an array
	*@return A newly allocated array of all bids ever placed by the company
	*/
public T[] toArray();
}
