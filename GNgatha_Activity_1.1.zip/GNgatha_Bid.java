/**
	Abstract Data Type that represents a bid by a company to install an  AC Unit for a client
	@author George K Ngatha

*/

public interface ACUnitBid<T>
{

/**
	*Specifies the name of the company placing the bid
	*@param the name of the company
	*/
void setCompanyName(String company);

/**
	*Determines whether the client is within the preferred 30miles radius
	*@return True if the client is within 30miles radius, or false if not.
	 */
public boolean isNear();

/**
	*Identifies the model of the AC unit requiring replacement
	*@return the AC unit model
	*/
public String getACUnitDescription();

/**
	*Determines whether the AC unit requiring replacement is a modern unit or an old style unit
	*@return True if unit is modern or false if unit is old styled unit
	*/
public boolean isACUnitModern();

/**
	*Provides manufacturer's quote for price of new repalcement unit based on model
	*@return the AC Unit Price
	*/
public double getACUnitPrice();

/**
	*Quote on the charge for diagnosing the old unit
	*@return Diagnostic Cost
	*/
public double  getDiagnosticCost();

/**
	*Quote on Labor cost for performing AC Unit replacement
	*@return Labor Cost
	*/
public double getLaborCost();

/**
	*Quote of disposing client's old AC Unit
	*@return Old Unit disposal cost
	*/
public double OldUnitDisposalCost();

/**
	*Qoute for distance Surcharge if client is >30miles away
	*@return Distance Surcharge
	*/
public double getDistanceSurchage();

/**
	*Final Quote including all applicable charges
	*@return Final Cost
	*/
public double getFinalCost();

/**
	*Tells the company if their bid won or failed
	*@return the bid status
	*/
public boolean getBidStatus();